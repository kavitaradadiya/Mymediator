import React from 'react'

export default function CommonSection(props) {
  return (
    <div>
         <div className='property_bg'><h4 className='property_head pt-4'>{props.title}</h4></div>
    </div>
  )
}
