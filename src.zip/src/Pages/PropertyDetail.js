import React, { useEffect, useState } from 'react'
import CommonSection from '../Components/CommonSection'
import { useParams } from 'react-router-dom'
import products from '../Components/Fakedata/product'
import ProductCard from './Category/ProductCard'

export default function PropertyDetail() {

  const { id } = useParams()
  console.log(id);


  const Product = products.find(item => item.id === id)
  console.log(Product)

  const { title, price, category, location, image01 } = Product;

  const [preImage, setPreImage] = useState(image01);

  const [allProduct, setAllProduct] = useState(products);

  useEffect(() => {

    if (category === "Property") {
      const FilterProduct = products.filter(item => item.category === "Property")
      // console.log(FilterProduct);
      setAllProduct(FilterProduct.slice(0, 4))
    }
    if (category === "Car") {
      const FilterProduct = products.filter(item => item.category === "Car")
      // console.log(FilterProduct);
      setAllProduct(FilterProduct.slice(0, 4))
    }
    if (category === "Bike") {
      const FilterProduct = products.filter(item => item.category === "Bike")
      // console.log(FilterProduct);
      setAllProduct(FilterProduct.slice(0, 4))
    }
    if (category === "Electronic") {
      const FilterProduct = products.filter(item => item.category === "Electronic")
      // console.log(FilterProduct);
      setAllProduct(FilterProduct.slice(0, 4))
    }

  }, [category])

  return (
    <div>
      {/* <div> <CommonSection title="Property Detail"></CommonSection></div>

      <section className='container mt-3 mb-3'>
        <div className='row'>
          <div className='col-lg-6 col-md-6 col-sm-12 col-12'>
            <div className='row'>
              <div className='col-lg-4 col-md-4 col-sm-6'>
                <div onClick={() => setPreImage(image01)}>
                  <img src={image01} alt='' className='img-fluid mt-2' width="90%"></img>
                </div>
                <div onClick={() => setPreImage(image01)}>
                  <img src={image01} alt='' className='img-fluid mt-2' width="90%"></img>
                </div>
                <div onClick={() => setPreImage(image01)}>
                  <img src={image01} alt='' className='img-fluid mt-2' width="90%"></img>
                </div>

              </div>
              <div className='col-lg-8 col-md-8 col-sm-6 mt-1'>
                <img src={preImage} alt='' className='img-fluid Property_img'></img>
              </div>
              <div className='Property_detail mt-4'>
                <h2>{title}</h2>
               
                <h3 className='mt-3'>{category}2021 <span className='ps-4'><img src='assets/img/vector1.png' alt='' className='img-fluid pe-2' width="30px"></img>4.5</span></h3>
                <h4 className='mt-3'><i className="ri-map-pin-2-fill product_icon pe-1"></i>{location}</h4>
              </div>
            </div>
          </div>
          <div className='col-lg-6 col-md-6 col-sm-12 col-12 mt-3'>
            <div className=''>
              <img src='assets/img/bell.png' alt='location-img' className='img-fluid mx-auto d-block' width="60%"></img>
              <div className='text-center mt-5'>
                <h3 className='propertydetail_price'>₹ {price}</h3>
                <button className='propertydetail_btn me-2'><img src='assets/img/mdi_speaking.png' alt='' className='img-fluid pe-2' width="25%"></img>Enquiry</button>
                <button className='propertydetail_btn'><img src='assets/img/frame185.png' alt='' className='img-fluid pe-1' width="18%"></img>Call</button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <hr />
      <section className='container'>
        <div className='row'>
          <div className='col-lg-7 col-md-7 col-sm-7 propertydetail_box '>
            <div className='container'>
              <div className='row pt-4'>
                <div className='col-lg-4 col-md-4 col-sm-4 text-center'>
                  <p><img src='assets/img/icon1.png' alt=''></img>990 Sq . Ft</p>
                </div>
                <div className='col-lg-4 col-md-4 col-sm-4 text-center'>
                  <p><img src='assets/img/icon1.png' alt=''></img>North Facing</p>
                </div>
                <div className='col-lg-4 col-md-4 col-sm-4 text-center'>
                  <p><img src='assets/img/icon1.png' alt=''></img>3 BHK</p>
                </div>
              </div>

              <hr/>

              <div className='row'>
                <div className='col-lg-4 col-md-4 col-sm-4 text-center'>
                </div>
                <div className='col-lg-4 col-md-4 col-sm-4 text-center'></div>
                <div className='col-lg-4 col-md-4 col-sm-4 text-center'></div>
              </div>
              
            </div>
          </div>
          
          <div className='col-lg-4 col-md-3 col-sm-3'></div>
        </div>
      </section>

      <section className='container'>
        <div className='row'>
          <h2 className='Propertydetail_rec'>Recommended Property</h2>
          {
            allProduct.map((item) => {
              return <div className='col-lg-3 col-md-3 col-sm-6' key={item.id}>
                <ProductCard items={item}></ProductCard>
              </div>
            })
          }
        </div>
      </section>

      <hr /> */}
    </div>
  )
}
