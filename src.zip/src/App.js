import React from 'react'
import './App.css'
import Layout from './Components/Layout'

export default function App() {
  return (
    <div>
      <Layout></Layout>
    </div>
  )
}
